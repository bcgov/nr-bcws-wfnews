# lua-tinyyaml
a tiny yaml (subset) parser for pure lua
